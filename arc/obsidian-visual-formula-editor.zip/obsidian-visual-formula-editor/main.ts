import {
  App,
  Editor,
  MarkdownView,
  Modal,
  Plugin,
  PluginSettingTab,
  Setting,
  Menu,
  MenuItem,
  Notice,
  MarkdownPostProcessorContext
} from 'obsidian';

// KaTeX Typings falls global verfügbar
declare const katex: {
  renderToString(tex: string, options?: { displayMode?: boolean; throwOnError?: boolean }): string;
};

interface FormulaEditorSettings {
  defaultMode: 'inline' | 'block';
  enableFloatingHoverButton: boolean;
  enableRibbonIcon: boolean;
  enableStatusBarItem: boolean;
  enableContextMenu: boolean;
  enableDirectClickEdit: boolean;
}

const DEFAULT_SETTINGS: FormulaEditorSettings = {
  defaultMode: 'block',
  enableFloatingHoverButton: false, // Standardmäßig aus, um störende Buttons an oberster Position oder im Read-Modus zu verhindern
  enableRibbonIcon: true,
  enableStatusBarItem: true,
  enableContextMenu: true,
  enableDirectClickEdit: true
};

interface ExtractedFormula {
  latex: string;
  isBlock: boolean;
  range?: {
    from: { line: number; ch: number };
    to: { line: number; ch: number };
  };
  fromOffset?: number;
  toOffset?: number;
  raw?: string;
  isInTable?: boolean;
}

/**
 * Bereinigt $ und $$ Begrenzer sowie UI-Strings
 */
function stripFormulaDelimiters(raw: string): string {
  let s = (raw || '').replace(/Σ\s*(?:Bearbeiten|Edit)/gi, '').trim();
  if (s.startsWith('$$') && s.endsWith('$$') && s.length >= 4) {
    return s.slice(2, -2).trim();
  }
  if (s.startsWith('$') && s.endsWith('$') && s.length >= 2) {
    return s.slice(1, -1).trim();
  }
  return s;
}

// Universeller DOM-Selektor für alle gerenderten MathJax- und KaTeX-Formelelemente
export const MATH_DOM_SELECTOR = 'mjx-container, .math, .math-block, .math-inline, .cm-math, .cm-math-block, .katex, .MathJax, [data-formula-editor-latex]';

/**
 * Obsidian Community Plugin: Visual Math Formula Editor (v1.0.8)
 * - Vollständige Unterstützung für Formeln in Markdown-Tabellen (Klick-zu-Bearbeiten direkt in Tabellenzellen)
 * - Tabellenzellen ohne Formel bleiben uneingeschränkt nativ editierbar (kein störendes Modal)
 * - Exakte Inline-Formel-Erkennung zeilenbasiert (kein Falsch-Mapping auf Formel 1)
 * - Block-Formeln bleiben echte Block-Formeln ($$\n...\n$$) ohne überflüssige Leerzeilen
 * - Keine zusätzlichen Leerzeilen darüber oder darunter beim Editieren
 * - Im Read-Modus erscheint kein störender Bearbeiten-Button
 * - Keine Geister-Buttons an oberster Notiz-Position
 */
export default class VisualFormulaEditorPlugin extends Plugin {
  settings: FormulaEditorSettings;
  floatingButtonEl: HTMLElement | null = null;
  hoveredMathEl: HTMLElement | null = null;
  hoveredFormulaData: ExtractedFormula | null = null;
  hideButtonTimeout: any = null;
  styleEl: HTMLStyleElement | null = null;

  async onload() {
    console.log('[VisualFormulaEditorPlugin] Loaded successfully (v1.0.8 - Table Formula Edit & Native Cell Coexistence)');
    await this.loadSettings();

    // 0. Styles dynamisch injizieren (sorgt für sofortige Aktualisierung ohne Cache-Probleme)
    this.injectPluginStyles();

    // 1. Schwebender "Σ Bearbeiten" Hover-Button (nur wenn explizit aktiviert)
    if (this.settings.enableFloatingHoverButton) {
      this.initFloatingHoverButton();
    }

    // 2. Status bar button (bottom right in Obsidian)
    if (this.settings.enableStatusBarItem) {
      const statusBarItem = this.addStatusBarItem();
      statusBarItem.createSpan({ text: 'Σ Formula Editor' });
      statusBarItem.title = 'Open Visual Formula Editor (Shortcut: Mod+Shift+M)';
      statusBarItem.addClass('mod-clickable');
      statusBarItem.style.cursor = 'pointer';
      statusBarItem.style.fontWeight = '500';
      statusBarItem.addEventListener('click', () => {
        this.openEditorFromCurrentContext();
      });
    }

    // 3. Ribbon Icon (left sidebar in Obsidian)
    if (this.settings.enableRibbonIcon) {
      this.addRibbonIcon('sigma', 'Open Formula Editor (Mod+Shift+M)', () => {
        this.openEditorFromCurrentContext();
      });
    }

    // 4. Keyboard shortcuts & Commands (Command Palette: Ctrl+P / Cmd+P)
    this.addCommand({
      id: 'open-visual-formula-editor',
      name: 'Open Visual Formula Editor (Edit current formula or insert new)',
      editorCallback: (editor: Editor, view: MarkdownView) => {
        this.openEditorForView(editor, view);
      },
      hotkeys: [{ modifiers: ['Mod', 'Shift'], key: 'M' }]
    });

    this.addCommand({
      id: 'insert-inline-math',
      name: 'Insert Inline Formula ($...$)',
      editorCallback: (editor: Editor) => {
        const cursor = editor.getCursor();
        const line = editor.getLine(cursor.line);
        const inTable = line.includes('|');
        new FormulaEditorModal(this.app, this, editor, '', false, undefined, undefined, undefined, undefined, inTable).open();
      },
      hotkeys: [{ modifiers: ['Mod', 'Shift'], key: 'I' }]
    });

    this.addCommand({
      id: 'insert-block-math',
      name: 'Insert Block Formula ($$...$$)',
      editorCallback: (editor: Editor) => {
        const cursor = editor.getCursor();
        const line = editor.getLine(cursor.line);
        const inTable = line.includes('|');
        new FormulaEditorModal(this.app, this, editor, '', !inTable, undefined, undefined, undefined, undefined, inTable).open();
      },
      hotkeys: [{ modifiers: ['Mod', 'Shift'], key: 'B' }]
    });

    // 5. Context menu in editor (right click in edit mode)
    if (this.settings.enableContextMenu) {
      this.registerEvent(
        this.app.workspace.on('editor-menu', (menu: Menu, editor: Editor) => {
          const selection = editor.getSelection();
          const cursor = editor.getCursor();
          const line = editor.getLine(cursor.line);
          const inTable = line.includes('|');
          const formulaMatch = this.detectFormulaUnderCursor(line, cursor.ch);

          menu.addItem((item: MenuItem) => {
            item
              .setTitle(formulaMatch ? 'Edit Formula (Visual Editor)' : 'Insert Formula (Visual Editor)')
              .setIcon('sigma')
              .onClick(() => {
                if (formulaMatch) {
                  new FormulaEditorModal(
                    this.app,
                    this,
                    editor,
                    formulaMatch.latex,
                    inTable ? false : formulaMatch.isBlock,
                    formulaMatch.range,
                    formulaMatch.latex,
                    undefined,
                    formulaMatch.raw,
                    inTable
                  ).open();
                } else if (selection) {
                  const defaultIsBlock = !inTable && (this.settings.defaultMode === 'block');
                  new FormulaEditorModal(
                    this.app,
                    this,
                    editor,
                    selection,
                    inTable ? false : (selection.includes('\\\\') || selection.length > 30 ? true : defaultIsBlock),
                    undefined,
                    selection,
                    undefined,
                    undefined,
                    inTable
                  ).open();
                } else {
                  const defaultIsBlock = !inTable && (this.settings.defaultMode === 'block');
                  new FormulaEditorModal(this.app, this, editor, '', defaultIsBlock, undefined, undefined, undefined, undefined, inTable).open();
                }
              });
          });
        })
      );
    }

    // 6. Direkter Klick auf gerenderte Formeln im Edit-Modus (Live Preview)
    if (this.settings.enableDirectClickEdit) {
      this.registerDomEvent(document, 'click', (evt: MouseEvent) => {
        const activeView = this.getActiveMarkdownView();
        // Im reinen Read-Modus (preview) nichts tun!
        if (!activeView || (activeView as any).getMode?.() === 'preview') return;

        const target = evt.target as HTMLElement;
        if (!target) return;
        if (this.floatingButtonEl && this.floatingButtonEl.contains(target)) return;

        // WICHTIG: Tabellen niemals als Formel abfangen!
        // Nur wenn direkt auf eine KaTeX/MathJax-Formel innerhalb der Zelle geklickt wurde:
        if (target.closest('table, .cm-table-widget, .table-wrapper, .table-editor, .markdown-rendered table')) {
          const directMath = target.closest(MATH_DOM_SELECTOR);
          if (!directMath) return; // Normaler Klick in Tabelle: Obsidian Tabelle wie gewohnt editieren lassen!
        }

        const mathEl = this.getTopMathContainer(target);
        if (mathEl) {
          // Prüfe ZUERST, ob eine gültige mathematische Formel gefunden werden kann!
          // NIEMALS das Klick-Event blockieren oder ein leeres Modal öffnen,
          // wenn gar keine Formel vorhanden ist!
          const formulaData = this.getFormulaFromMathElement(mathEl, activeView);
          if (formulaData && formulaData.latex && formulaData.latex.trim().length > 0) {
            evt.preventDefault();
            evt.stopPropagation();
            const isInTable = Boolean(
              formulaData.isInTable ||
              target.closest('table, .cm-table-widget, .table-wrapper, .table-editor, .markdown-rendered table') ||
              mathEl.closest('table, .cm-table-widget, .table-wrapper, .table-editor, .markdown-rendered table')
            );
            new FormulaEditorModal(
              this.app,
              this,
              activeView.editor,
              formulaData.latex,
              isInTable ? false : formulaData.isBlock,
              undefined,
              formulaData.latex,
              formulaData.range,
              formulaData.raw,
              isInTable
            ).open();
          }
        }
      });
    }

    // 7. Markdown Post-Processor (Für Reading-Modus zur Datenanreicherung ohne UI-Buttons)
    this.registerMarkdownPostProcessor((element: HTMLElement, context: MarkdownPostProcessorContext) => {
      const allMath = Array.from(element.querySelectorAll<HTMLElement>('.math, .math-inline, .math-block, mjx-container, .katex'));
      const topMath = allMath.filter(el => !allMath.some(p => p !== el && p.contains(el)));
      if (topMath.length === 0) return;

      const sectionInfo = context && typeof context.getSectionInfo === 'function' ? context.getSectionInfo(element) : null;
      const formulas: Array<{ latex: string; isBlock: boolean; raw: string }> = [];

      if (sectionInfo && sectionInfo.text) {
        const lines = sectionInfo.text.split('\n');
        const sectionText = lines.slice(sectionInfo.lineStart, sectionInfo.lineEnd + 1).join('\n');
        const mathRegex = /(\$\$[\s\S]*?\$\$|(?<![\$\\])\$(?!\$)([^\$\n]+?)(?<![\$\\])\$(?!\$))/g;
        let match;
        while ((match = mathRegex.exec(sectionText)) !== null) {
          const raw = match[0];
          const isBlock = raw.startsWith('$$');
          formulas.push({
            latex: isBlock ? raw.slice(2, -2).trim() : raw.slice(1, -1).trim(),
            isBlock,
            raw
          });
        }
      }

      topMath.forEach((topEl, idx) => {
        const f = formulas[idx];
        if (f) {
          topEl.setAttribute('data-formula-editor-latex', f.latex);
          topEl.setAttribute('data-formula-editor-block', String(f.isBlock));
          topEl.setAttribute('data-formula-editor-raw', f.raw);
        }
      });
    });

    // 8. Einstellungen
    this.addSettingTab(new FormulaEditorSettingTab(this.app, this));
  }

  onunload() {
    console.log('[VisualFormulaEditorPlugin] Unloaded');
    if (this.floatingButtonEl && this.floatingButtonEl.parentElement) {
      this.floatingButtonEl.remove();
    }
    this.removePluginStyles();
  }

  injectPluginStyles() {
    this.removePluginStyles();
    const css = `
      /* 1. Block-Formeln im Edit-Modus (Live Preview) */
      .markdown-source-view.mod-cm6 .cm-embed-block.cm-math-block,
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(.math-block),
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(mjx-container[jax="CHTML"][display="true"]),
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(mjx-container[display="true"]),
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(.katex-display),
      .markdown-source-view.mod-cm6 .math.math-block {
        position: relative !important;
        border: 1px solid transparent !important;
        background-color: transparent !important;
        border-radius: var(--radius-m, 8px) !important;
        padding: 6px 12px !important;
        margin: 6px 0 !important;
        box-shadow: none !important;
        transition: border-color 0.15s ease, background-color 0.15s ease, box-shadow 0.15s ease !important;
      }

      /* Äußere Wrapper entlasten, mathematische Binnenstriche (mjx-line, frac-line, sqrt etc.) VOLLSTÄNDIG intakt lassen */
      .markdown-source-view.mod-cm6 .cm-embed-block.cm-math-block mjx-container,
      .markdown-source-view.mod-cm6 .cm-embed-block.cm-math-block .math,
      .markdown-source-view.mod-cm6 .cm-embed-block.cm-math-block .katex,
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(mjx-container[display="true"]) mjx-container,
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(.katex-display) .katex,
      .markdown-source-view.mod-cm6 .math.math-block mjx-container,
      .markdown-source-view.mod-cm6 .math.math-block .math,
      .markdown-source-view.mod-cm6 .math.math-block .katex,
      .markdown-source-view.mod-cm6 .math-inline mjx-container,
      .markdown-source-view.mod-cm6 .math-inline .katex {
        border: none !important;
        background: transparent !important;
        box-shadow: none !important;
      }

      /* Block-Hover im Edit-Modus: Genau EINE Umrandung und dezente Hinterlegung */
      .markdown-source-view.mod-cm6 .cm-embed-block.cm-math-block:hover,
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(.math-block):hover,
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(mjx-container[jax="CHTML"][display="true"]):hover,
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(mjx-container[display="true"]):hover,
      .markdown-source-view.mod-cm6 .cm-embed-block:not(.cm-table-widget):not(:has(table)):has(.katex-display):hover,
      .markdown-source-view.mod-cm6 .math.math-block:hover {
        border: 1px solid var(--interactive-accent, #a855f7) !important;
        background-color: var(--color-accent-subtle, rgba(168, 85, 247, 0.12)) !important;
        box-shadow: 0 0 0 1px var(--interactive-accent, #a855f7) !important;
        border-radius: var(--radius-m, 8px) !important;
        cursor: pointer !important;
      }

      /* Native Edit-Buttons und Artefakte auf Blöcken restlos ausblenden */
      .markdown-source-view.mod-cm6 .edit-block-button,
      .markdown-source-view.mod-cm6 .edit-block-button:hover,
      .markdown-source-view.mod-cm6 [aria-label="Edit this block"],
      .markdown-source-view.mod-cm6 [aria-label="Edit this block"]:hover,
      .markdown-source-view.mod-cm6 .cm-embed-block .edit-block-button,
      .markdown-source-view.mod-cm6 .cm-embed-block:hover .edit-block-button,
      .markdown-source-view.mod-cm6 .cm-embed-block.cm-math-block::before,
      .markdown-source-view.mod-cm6 .cm-embed-block.cm-math-block::after,
      .markdown-source-view.mod-cm6 .cm-embed-block:has(mjx-container)::before,
      .markdown-source-view.mod-cm6 .cm-embed-block:has(mjx-container)::after,
      .markdown-source-view.mod-cm6 .math-block::before,
      .markdown-source-view.mod-cm6 .math-block::after,
      .edit-block-button,
      [aria-label="Edit this block"] {
        display: none !important;
        opacity: 0 !important;
        visibility: hidden !important;
        pointer-events: none !important;
        width: 0 !important;
        height: 0 !important;
        max-width: 0 !important;
        max-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        border: none !important;
        background: transparent !important;
        box-shadow: none !important;
        position: absolute !important;
        top: -9999px !important;
        left: -9999px !important;
        content: none !important;
      }

      /* 2. Inline-Formeln im Edit-Modus (Fließtext und Tabellenzellen) */
      .markdown-source-view.mod-cm6 .math-inline,
      .markdown-source-view.mod-cm6 .math:not(.math-block):not(:has(table)),
      .markdown-source-view.mod-cm6 mjx-container:not([display="true"]):not(.math-inline mjx-container):not(.math mjx-container),
      .markdown-source-view.mod-cm6 .katex:not(.katex-display):not(.math-inline .katex):not(.math .katex) {
        position: relative !important;
        display: inline-block !important;
        padding: 1px 4px !important;
        margin: 0 1px !important;
        border-radius: var(--radius-s, 4px) !important;
        border: 1px solid transparent !important;
        background-color: transparent !important;
        box-shadow: none !important;
        transition: border-color 0.15s ease, background-color 0.15s ease, box-shadow 0.15s ease !important;
      }

      /* Inline-Hover im Edit-Modus: Genau EINE Umrandung und dezente Hinterlegung */
      .markdown-source-view.mod-cm6 .math-inline:hover,
      .markdown-source-view.mod-cm6 .math:not(.math-block):not(:has(table)):hover,
      .markdown-source-view.mod-cm6 mjx-container:not([display="true"]):not(.math-inline mjx-container):not(.math mjx-container):hover,
      .markdown-source-view.mod-cm6 .katex:not(.katex-display):not(.math-inline .katex):not(.math .katex):hover {
        border: 1px solid var(--interactive-accent, #a855f7) !important;
        background-color: var(--color-accent-subtle, rgba(168, 85, 247, 0.14)) !important;
        box-shadow: 0 0 0 1px var(--interactive-accent, #a855f7) !important;
        border-radius: var(--radius-s, 4px) !important;
        cursor: pointer !important;
      }

      /* Keine innere Doppel-Umrandung in Tabellenzellen */
      .markdown-source-view.mod-cm6 .math-inline mjx-container,
      .markdown-source-view.mod-cm6 .math-inline .katex,
      .markdown-source-view.mod-cm6 .math mjx-container,
      .markdown-source-view.mod-cm6 .math .katex,
      .markdown-source-view.mod-cm6 .math-inline mjx-container:hover,
      .markdown-source-view.mod-cm6 .math-inline .katex:hover,
      .markdown-source-view.mod-cm6 .math mjx-container:hover,
      .markdown-source-view.mod-cm6 .math .katex:hover {
        border: 1px solid transparent !important;
        background-color: transparent !important;
        box-shadow: none !important;
        padding: 0 !important;
        margin: 0 !important;
      }

      /* Read-Modus: Keine Bearbeitungs-Umrandungen */
      .markdown-rendered .math,
      .markdown-rendered .math-block,
      .markdown-rendered .math-inline,
      .markdown-rendered mjx-container,
      .markdown-rendered .katex,
      .markdown-preview-view .math,
      .markdown-preview-view .math-block,
      .markdown-preview-view .math-inline,
      .markdown-rendered .math:hover,
      .markdown-rendered .math-block:hover,
      .markdown-rendered .math-inline:hover,
      .markdown-rendered mjx-container:hover,
      .markdown-rendered .katex:hover,
      .markdown-preview-view .math:hover,
      .markdown-preview-view .math-block:hover,
      .markdown-preview-view .math-inline:hover {
        border: none !important;
        background: transparent !important;
        box-shadow: none !important;
        cursor: default !important;
      }
    `;

    try {
      if (typeof document !== 'undefined' && document.head && typeof document.createElement === 'function') {
        this.styleEl = document.createElement('style');
        this.styleEl.id = 'obsidian-visual-formula-editor-styles';
        this.styleEl.textContent = css;
        document.head.appendChild(this.styleEl);
      }
    } catch (_e) {}
  }

  removePluginStyles() {
    try {
      if (this.styleEl && this.styleEl.parentElement) {
        this.styleEl.remove();
        this.styleEl = null;
      }
      if (typeof document !== 'undefined' && typeof document.getElementById === 'function') {
        const existing = document.getElementById('obsidian-visual-formula-editor-styles');
        if (existing && existing.parentElement) {
          existing.remove();
        }
      }
    } catch (_e) {}
  }

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  /**
   * Findet den echten Mathe-Container für ein beliebiges DOM-Element (schließt Tabellen und sonstige Widgets strikt aus)
   */
  getTopMathContainer(target: HTMLElement | null): HTMLElement | null {
    if (!target) return null;

    // 1. Wenn der Klick innerhalb einer Tabelle, Zeile oder Zelle liegt:
    // Tabellen (.cm-table-widget, table, td, th, etc.) NIE als Mathe-Container ansehen!
    if (target.closest('table, .cm-table-widget, .table-wrapper, .table-editor, .markdown-rendered table')) {
      // Nur zulassen, wenn das Ziel selbst ein explizites Mathe-Element innerhalb der Zelle ist
      const directMath = target.closest(MATH_DOM_SELECTOR) as HTMLElement | null;
      if (!directMath) {
        return null;
      }
      return directMath;
    }

    // 2. Callouts, Codeblöcke oder sonstige Widgets ausschließen
    if (target.closest('.callout, .cm-callout, pre, code:not(.cm-math)')) {
      const directMath = target.closest(MATH_DOM_SELECTOR) as HTMLElement | null;
      if (!directMath) return null;
      return directMath;
    }

    // 3. Nur Elemente prüfen, die tatsächlich Mathe-Klassen/Tags haben
    let el = target.closest(MATH_DOM_SELECTOR) as HTMLElement | null;

    if (!el) {
      // Prüfe, ob es ein cm-embed-block ist, der tatsächlich ein Mathe-Block ist (.cm-math-block)
      // WICHTIG: KEIN generisches 'svg' matchen! Tabellen, Embeds und Icons haben auch SVGs!
      const embed = target.closest('.cm-embed-block') as HTMLElement | null;
      if (embed) {
        // Tabellen-Embeds strikt ausschließen
        if (embed.classList.contains('cm-table-widget') || embed.querySelector('table')) {
          return null;
        }
        if (embed.classList.contains('cm-math-block')) {
          el = embed;
        } else {
          const innerMath = embed.querySelector(MATH_DOM_SELECTOR) as HTMLElement | null;
          if (innerMath) {
            el = innerMath;
          } else {
            return null;
          }
        }
      } else {
        return null;
      }
    }

    // Nach oben wandern solange übergeordnet noch ein Mathe-Element ist (nicht in Tabellenzellen hinein!)
    while (el && el.parentElement && !el.parentElement.matches('td, th, table, tr, tbody, thead')) {
      const parentMath = el.parentElement.closest(MATH_DOM_SELECTOR) as HTMLElement | null;

      if (parentMath && parentMath !== el) {
        el = parentMath;
      } else {
        break;
      }
    }
    return el;
  }

  /**
   * Gibt den aktuell aktiven MarkdownView zurück
   */
  getActiveMarkdownView(): MarkdownView | null {
    const activeView = this.app.workspace.getActiveViewOfType(MarkdownView);
    if (activeView) return activeView;

    const activeLeaf = (this.app.workspace as any).activeLeaf;
    if (activeLeaf && activeLeaf.view instanceof MarkdownView) {
      return activeLeaf.view;
    }

    const leaves = this.app.workspace.getLeavesOfType('markdown');
    if (leaves.length > 0 && leaves[0].view instanceof MarkdownView) {
      return leaves[0].view;
    }

    return null;
  }

  /**
   * Initialisiert den schwebenden "Σ Bearbeiten" Button direkt an der Formel
   */
  initFloatingHoverButton() {
    const btn = document.createElement('div');
    btn.className = 'formula-editor-floating-badge';
    btn.innerHTML = '<span style="color:#fbbf24;font-weight:bold;margin-right:4px;font-size:11px;">Σ</span> Edit';
    btn.title = 'Edit formula in visual editor';

    btn.style.cssText = `
      position: fixed;
      display: none;
      z-index: 999999;
      background: var(--background-secondary-alt, #262626);
      color: var(--text-normal, #f4f4f5);
      border: 1px solid var(--interactive-accent, #7c3aed);
      border-radius: 4px;
      padding: 2px 7px;
      font-size: 11px;
      font-weight: 600;
      font-family: var(--font-ui, sans-serif);
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(0,0,0,0.35);
      align-items: center;
      user-select: none;
      pointer-events: auto;
      transition: background 0.15s ease;
    `;

    btn.addEventListener('mouseenter', () => {
      if (this.hideButtonTimeout) clearTimeout(this.hideButtonTimeout);
      btn.style.display = 'inline-flex';
      btn.style.background = 'var(--interactive-accent, #7c3aed)';
      btn.style.color = '#ffffff';
    });

    btn.addEventListener('mouseleave', () => {
      btn.style.background = 'var(--background-secondary-alt, #262626)';
      btn.style.color = 'var(--text-normal, #f4f4f5)';
      this.hideButton(true);
    });

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      if (this.hoveredMathEl) {
        this.openEditorFromTarget(this.hoveredMathEl);
        this.hideButton(true);
      }
    });

    document.body.appendChild(btn);
    this.floatingButtonEl = btn;

    // Globale Hover-Erkennung für Formeln (NUR im Edit-Modus)
    this.registerDomEvent(document, 'mouseover', (evt: MouseEvent) => {
      const activeView = this.getActiveMarkdownView();
      // Im Read-Modus (preview) NIEMALS einen Button anzeigen!
      if (!activeView || (activeView as any).getMode?.() === 'preview') {
        this.hideButton(true);
        return;
      }

      const target = evt.target as HTMLElement;
      if (!target) return;
      if (btn.contains(target)) return;

      if (target.closest('table, .cm-table-widget, .table-wrapper, .table-editor')) {
        const directMath = target.closest(MATH_DOM_SELECTOR);
        if (!directMath) {
          this.hideButton(true);
          return;
        }
      }

      const mathEl = this.getTopMathContainer(target);

      if (mathEl) {
        // Nicht an oberster Position oder außerhalb des Editorbereichs anzeigen
        const innerVisual = (mathEl.querySelector('mjx-container, .math-block, .math-inline, .katex') as HTMLElement) || mathEl;
        const rect = innerVisual.getBoundingClientRect();

        // Mindestabstand nach oben (mind. 40px vom oberen Fensterrand entfernt)
        if (rect.width > 0 && rect.height > 0 && rect.top >= 40 && rect.top <= window.innerHeight - 40) {
          if (this.hideButtonTimeout) clearTimeout(this.hideButtonTimeout);
          this.hoveredMathEl = mathEl;

          const top = rect.top - 24;
          const left = Math.max(12, rect.left);
          btn.style.top = `${top}px`;
          btn.style.left = `${left}px`;
          btn.style.display = 'inline-flex';
        }
      } else {
        this.hideButton();
      }
    });
  }

  hideButton(immediate = false) {
    if (immediate) {
      if (this.floatingButtonEl) this.floatingButtonEl.style.display = 'none';
      this.hoveredMathEl = null;
      this.hoveredFormulaData = null;
      return;
    }

    if (this.hideButtonTimeout) clearTimeout(this.hideButtonTimeout);
    this.hideButtonTimeout = setTimeout(() => {
      if (this.floatingButtonEl) {
        this.floatingButtonEl.style.display = 'none';
      }
      this.hoveredMathEl = null;
      this.hoveredFormulaData = null;
    }, 200);
  }

  /**
   * Öffnet den Formeleditor aus der aktuellen Notiz (Cursor-basiert)
   */
  openEditorFromCurrentContext() {
    const activeView = this.getActiveMarkdownView();
    if (!activeView) {
      new Notice('Bitte öffnen Sie zuerst eine Markdown-Notiz!');
      return;
    }
    this.openEditorForView(activeView.editor, activeView);
  }

  /**
   * Öffnet den Formeleditor für einen Editor
   */
  openEditorForView(editor: Editor, view?: MarkdownView) {
    const cursor = editor.getCursor();
    const line = editor.getLine(cursor.line);
    const inTable = line.includes('|');
    const formulaMatch = this.detectFormulaUnderCursor(line, cursor.ch);
    const selection = editor.getSelection();

    if (formulaMatch) {
      new FormulaEditorModal(
        this.app,
        this,
        editor,
        formulaMatch.latex,
        inTable ? false : formulaMatch.isBlock,
        formulaMatch.range,
        formulaMatch.latex,
        undefined,
        formulaMatch.raw,
        inTable
      ).open();
      return;
    }

    if (selection && selection.trim().length > 0) {
      let selText = selection.trim();
      const defaultIsBlock = !inTable && (this.settings.defaultMode === 'block');
      let isBlockSel = defaultIsBlock;
      if (selText.startsWith('$$') && selText.endsWith('$$') && selText.length >= 4) {
        selText = selText.slice(2, -2).trim();
        isBlockSel = !inTable;
      } else if (selText.startsWith('$') && selText.endsWith('$') && selText.length >= 2) {
        selText = selText.slice(1, -1).trim();
        isBlockSel = false;
      }
      new FormulaEditorModal(this.app, this, editor, selText, inTable ? false : isBlockSel, undefined, selText, undefined, undefined, inTable).open();
      return;
    }

    // Wenn der Cursor unmittelbar an einer Formel steht
    const fullText = editor.getValue();
    const cursorOffset = editor.posToOffset(cursor);
    const foundNear = this.findFormulaAroundPos(fullText, cursorOffset);
    if (foundNear && cursorOffset >= foundNear.fromOffset && cursorOffset <= foundNear.toOffset) {
      new FormulaEditorModal(
        this.app,
        this,
        editor,
        foundNear.latex,
        inTable ? false : foundNear.isBlock,
        undefined,
        foundNear.latex,
        {
          from: editor.offsetToPos(foundNear.fromOffset),
          to: editor.offsetToPos(foundNear.toOffset)
        },
        foundNear.raw,
        inTable
      ).open();
      return;
    }

    // Ansonsten NEUE Formel einfügen (beachtet defaultMode aus Einstellungen)!
    const defaultIsBlock = !inTable && (this.settings.defaultMode === 'block');
    new FormulaEditorModal(this.app, this, editor, '', defaultIsBlock, undefined, undefined, undefined, undefined, inTable).open();
  }

  /**
   * Öffnet den Editor für ein geklicktes Element.
   * Ermittelt IMMER die spezifische Formel dieses Elements.
   */
  openEditorFromTarget(mathEl: HTMLElement) {
    const activeView = this.getActiveMarkdownView();
    const editor = activeView ? activeView.editor : undefined;

    const formulaData = this.getFormulaFromMathElement(mathEl, activeView);

    if (formulaData && formulaData.latex) {
      const isInTable = Boolean(
        formulaData.isInTable ||
        mathEl.closest('table, .cm-table-widget, .table-wrapper, .table-editor, .markdown-rendered table')
      );
      new FormulaEditorModal(
        this.app,
        this,
        editor,
        formulaData.latex,
        isInTable ? false : formulaData.isBlock,
        undefined,
        formulaData.latex,
        formulaData.range,
        formulaData.raw,
        isInTable
      ).open();
      return;
    }

    // Wenn keine Formel extrahiert werden konnte (z.B. Tabelle oder sonstiges Element):
    // NIEMALS ein leeres Modal öffnen!
  }

  /**
   * Extrahiert die LaTeX-Formel direkt aus dem DOM (z. B. MathJax <annotation>, KaTeX MathML oder data-Attribute)
   */
  extractLatexFromDOM(mathEl: HTMLElement): string | null {
    if (!mathEl) return null;

    // 1. Gespeichertes data-Attribut (aus Post-Processor oder Editor)
    const attrLatex = mathEl.getAttribute('data-formula-editor-latex') ||
      mathEl.getAttribute('data-tex') ||
      mathEl.getAttribute('alt');
    if (attrLatex && attrLatex.trim()) {
      return stripFormulaDelimiters(attrLatex.trim());
    }

    // 2. MathJax & KaTeX Assistive MathML <annotation> (Standard bei Obsidian)
    const annotation = mathEl.querySelector('annotation[encoding*="tex"], annotation');
    if (annotation && annotation.textContent && annotation.textContent.trim()) {
      return stripFormulaDelimiters(annotation.textContent.trim());
    }

    // 3. Assistive MathML in Kind-Elementen
    const mml = mathEl.querySelector('mjx-assistive-mml, .katex-mathml');
    if (mml) {
      const ann = mml.querySelector('annotation');
      if (ann && ann.textContent && ann.textContent.trim()) {
        return stripFormulaDelimiters(ann.textContent.trim());
      }
    }

    // 4. aria-label oder title
    const aria = mathEl.getAttribute('aria-label') || mathEl.getAttribute('title');
    if (aria && aria.trim().startsWith('$') && aria.trim().endsWith('$')) {
      return stripFormulaDelimiters(aria.trim());
    }

    return null;
  }

  /**
   * Findet eine Formel innerhalb einer gerenderten Tabelle im Markdown-Dokument
   */
  findTableFormula(
    editor: Editor,
    docText: string,
    mathEl: HTMLElement,
    tableEl: HTMLElement
  ): ExtractedFormula | null {
    // 1. LaTeX-Formel direkt aus dem DOM extrahieren (falls vorhanden)
    const domLatex = this.extractLatexFromDOM(mathEl);
    const cleanDomLatex = domLatex ? stripFormulaDelimiters(domLatex) : null;

    // 2. Tabellen-Metadaten aus dem DOM ermitteln (Zell- & Zeilen-Index)
    const cellEl = mathEl.closest('td, th') as HTMLTableCellElement | null;
    const rowEl = mathEl.closest('tr') as HTMLTableRowElement | null;
    const colIdx = cellEl ? cellEl.cellIndex : -1;
    const rowIdx = rowEl ? rowEl.rowIndex : -1;
    const isHeader = Boolean(mathEl.closest('th, thead'));

    // 3. Tabellen-Offset in CodeMirror 6 ermitteln
    const cmView = (editor as any).cm;
    let tableOffset = -1;
    if (cmView && typeof cmView.posAtDOM === 'function') {
      try {
        const embedEl = mathEl.closest('.cm-embed-block') || tableEl;
        const pos = cmView.posAtDOM(embedEl);
        if (typeof pos === 'number' && !isNaN(pos)) {
          tableOffset = pos;
        }
      } catch (e) {}
    }

    // 4. Zeilen des Dokuments durchgehen und Markdown-Tabellenblöcke identifizieren
    const lines = docText.split('\n');
    interface MdTable {
      startLine: number;
      endLine: number;
      headerLine: number;
      separatorLine: number;
      dataLines: number[];
      allLines: number[];
    }

    const tables: MdTable[] = [];
    let curTable: MdTable | null = null;

    for (let l = 0; l < lines.length; l++) {
      const lineText = lines[l];
      const isTableRow = lineText.includes('|') && lineText.trim().length > 0;

      if (isTableRow) {
        if (!curTable) {
          curTable = {
            startLine: l,
            endLine: l,
            headerLine: l,
            separatorLine: -1,
            dataLines: [],
            allLines: [l]
          };
        } else {
          curTable.endLine = l;
          curTable.allLines.push(l);
          // Trennzeile (| --- | --- |) erkennen
          if (curTable.separatorLine === -1 && /^\|?(\s*:?-+:?\s*\|)+\s*:?-+:?\s*\|?$/.test(lineText.trim())) {
            curTable.separatorLine = l;
          } else {
            curTable.dataLines.push(l);
          }
        }
      } else {
        if (curTable) {
          tables.push(curTable);
          curTable = null;
        }
      }
    }
    if (curTable) {
      tables.push(curTable);
    }

    if (tables.length === 0) return null;

    // 5. Ziel-Tabelle bestimmen: Entweder über tableOffset oder über Tabellen-Index im DOM
    let targetTable: MdTable | null = null;
    if (tableOffset >= 0) {
      const tablePos = editor.offsetToPos(tableOffset);
      targetTable = tables.find(t => tablePos.line >= t.startLine - 2 && tablePos.line <= t.endLine + 2) || null;
    }

    if (!targetTable) {
      // Wenn domLatex bekannt ist, suche die Tabelle, die diesen Text enthält
      if (cleanDomLatex) {
        targetTable = tables.find(t => {
          return t.allLines.some(lineIdx => lines[lineIdx].includes(cleanDomLatex));
        }) || null;
      }
    }

    if (!targetTable) {
      // Fallback: DOM-Index der Tabelle im Notiz-Container
      const viewContainer = document.querySelector('.workspace-leaf.mod-active') || document.body;
      const allDomTables = Array.from(viewContainer.querySelectorAll('table, .cm-table-widget'));
      const tIdx = allDomTables.indexOf(tableEl);
      if (tIdx >= 0 && tIdx < tables.length) {
        targetTable = tables[tIdx];
      } else {
        targetTable = tables[0];
      }
    }

    if (!targetTable) return null;

    // 6. Zielzeile in der Markdown-Tabelle bestimmen
    let targetLineNum = -1;
    if (isHeader) {
      targetLineNum = targetTable.headerLine;
    } else if (rowIdx >= 1 && targetTable.dataLines.length > 0) {
      // In thead ist row 0, in tbody ist row 1 die erste Datenzeile (Index 0 in dataLines)
      const dataIdx = Math.min(rowIdx - 1, targetTable.dataLines.length - 1);
      targetLineNum = targetTable.dataLines[dataIdx];
    }

    // 7. Formel in der Zeile (oder in der gesamten Tabelle) lokalisieren
    const inlineMathRegex = /(?<![\$\\])\$(?!\$)([^\$\n]+?)(?<![\$\\])\$(?!\$)/g;

    const searchLineForFormula = (lineNum: number) => {
      const lineStr = lines[lineNum];
      if (!lineStr) return null;

      // Wenn wir eine Spaltenposition haben, können wir die Zelle analysieren
      if (colIdx >= 0) {
        // Zellen anhand von '|' parsen (Escaped pipes \| berücksichtigen)
        const cellParts: Array<{ text: string; startCh: number; endCh: number }> = [];
        let inCell = false;
        let cellStart = 0;
        let cellContent = '';

        for (let idx = 0; idx < lineStr.length; idx++) {
          const char = lineStr[idx];
          const prevChar = idx > 0 ? lineStr[idx - 1] : '';

          if (char === '|' && prevChar !== '\\') {
            if (inCell) {
              cellParts.push({ text: cellContent, startCh: cellStart, endCh: idx });
              cellContent = '';
            }
            inCell = true;
            cellStart = idx + 1;
          } else if (inCell) {
            cellContent += char;
          }
        }
        if (inCell && cellContent.trim().length > 0) {
          cellParts.push({ text: cellContent, startCh: cellStart, endCh: lineStr.length });
        }

        if (colIdx < cellParts.length) {
          const targetCell = cellParts[colIdx];
          // Formel innerhalb dieser spezifischen Zelle suchen
          let m: RegExpExecArray | null;
          inlineMathRegex.lastIndex = 0;
          while ((m = inlineMathRegex.exec(targetCell.text)) !== null) {
            const formulaLatex = m[1].trim();
            if (!cleanDomLatex || formulaLatex === cleanDomLatex || formulaLatex.replace(/\s+/g, '') === cleanDomLatex.replace(/\s+/g, '')) {
              const startCh = targetCell.startCh + m.index;
              const endCh = startCh + m[0].length;
              return {
                latex: formulaLatex,
                isBlock: false,
                isInTable: true,
                range: {
                  from: { line: lineNum, ch: startCh },
                  to: { line: lineNum, ch: endCh }
                },
                raw: m[0]
              };
            }
          }
        }
      }

      // Falls Spaltensuche fehlschlug oder colIdx < 0: Suche auf der ganzen Zeile
      let m: RegExpExecArray | null;
      inlineMathRegex.lastIndex = 0;
      while ((m = inlineMathRegex.exec(lineStr)) !== null) {
        const formulaLatex = m[1].trim();
        if (!cleanDomLatex || formulaLatex === cleanDomLatex || formulaLatex.replace(/\s+/g, '') === cleanDomLatex.replace(/\s+/g, '')) {
          return {
            latex: formulaLatex,
            isBlock: false,
            isInTable: true,
            range: {
              from: { line: lineNum, ch: m.index },
              to: { line: lineNum, ch: m.index + m[0].length }
            },
            raw: m[0]
          };
        }
      }

      return null;
    };

    // Zuerst auf der ermittelten Zeile suchen
    if (targetLineNum >= 0) {
      const match = searchLineForFormula(targetLineNum);
      if (match) return match;
    }

    // Wenn nicht gefunden: Alle Zeilen dieser Tabelle durchsuchen
    for (const lNum of targetTable.allLines) {
      if (lNum === targetTable.separatorLine) continue;
      const match = searchLineForFormula(lNum);
      if (match) return match;
    }

    // Fallback: Wenn wir cleanDomLatex haben, aber die Zeilensuche scheiterte,
    // suche cleanDomLatex im gesamten Dokument
    if (cleanDomLatex) {
      const esc = cleanDomLatex.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const flexRegex = new RegExp('\\$([^$\\n]*?' + esc + '[^$\\n]*?)\\$', 'g');
      let fm: RegExpExecArray | null;
      while ((fm = flexRegex.exec(docText)) !== null) {
        const linePos = editor.offsetToPos(fm.index);
        const lineText = lines[linePos.line] || '';
        if (lineText.includes('|')) {
          return {
            latex: fm[1].trim(),
            isBlock: false,
            isInTable: true,
            range: {
              from: editor.offsetToPos(fm.index),
              to: editor.offsetToPos(fm.index + fm[0].length)
            },
            raw: fm[0]
          };
        }
      }
    }

    return null;
  }

  /**
   * Ermittelt die exakte mathematische Formel aus einem beliebigen Mathe-Container.
   * 0. Tabellen-Formeln in Live Preview
   * 1. Zeilenbasierte CodeMirror 6 Erkennung für Inline-Formeln
   * 2. Block-Erkennung für display-math
   */
  getFormulaFromMathElement(
    mathEl: HTMLElement,
    view?: MarkdownView | null
  ): ExtractedFormula | null {
    const editor = view?.editor;
    const docText = editor ? editor.getValue() : '';

    // 0. VORRANG: Prüfe, ob sich mathEl in einer Tabelle befindet
    const tableEl = mathEl.closest('table, .cm-table-widget, .table-wrapper, .table-editor, .markdown-rendered table') as HTMLElement | null;
    if (tableEl && editor && docText) {
      const tableFormula = this.findTableFormula(editor, docText, mathEl, tableEl);
      if (tableFormula) {
        return tableFormula;
      }
    }

    // 1. ZUERST: Prüfe, ob es sich in einer CodeMirror-Zeile befindet (.cm-line)
    const lineEl = mathEl.closest('.cm-line') as HTMLElement | null;
    if (editor && lineEl) {
      const cmView = (editor as any).cm;
      if (cmView && typeof cmView.posAtDOM === 'function') {
        try {
          const lineOffset = cmView.posAtDOM(lineEl);
          if (typeof lineOffset === 'number' && !isNaN(lineOffset)) {
            const linePos = editor.offsetToPos(lineOffset);
            const lineNum = linePos.line;
            const lineContent = editor.getLine(lineNum);

            // Inline-Formeln auf dieser konkreten Zeile suchen
            const inlineRegex = /(?<![\$\\])\$(?!\$)([^\$\n]+?)(?<![\$\\])\$(?!\$)/g;
            const formulasOnLine: Array<{ latex: string; start: number; end: number; raw: string }> = [];
            let im: RegExpExecArray | null;
            while ((im = inlineRegex.exec(lineContent)) !== null) {
              formulasOnLine.push({
                latex: im[1].trim(),
                start: im.index,
                end: im.index + im[0].length,
                raw: im[0]
              });
            }

            if (formulasOnLine.length > 0) {
              // Alle Mathe-Elemente auf dieser DOM-Zeile finden
              const mathOnLine = Array.from(lineEl.querySelectorAll<HTMLElement>('mjx-container, .math-inline, .cm-math'))
                .filter((el, idx, arr) => !arr.some(p => p !== el && p.contains(el)));

              let mathIdx = mathOnLine.findIndex(el => el === mathEl || el.contains(mathEl) || mathEl.contains(el));
              if (mathIdx < 0) mathIdx = 0;
              const chosen = formulasOnLine[Math.min(mathIdx, formulasOnLine.length - 1)];

              return {
                latex: chosen.latex,
                isBlock: false,
                range: {
                  from: { line: lineNum, ch: chosen.start },
                  to: { line: lineNum, ch: chosen.end }
                },
                raw: chosen.raw
              };
            }

            // Falls auf der Zeile eine Block-Formel liegt ($$...$$)
            const blockRegex = /\$\$([\s\S]*?)\$\$/g;
            const bm = blockRegex.exec(lineContent);
            if (bm) {
              return {
                latex: bm[1].trim(),
                isBlock: true,
                range: {
                  from: { line: lineNum, ch: bm.index },
                  to: { line: lineNum, ch: bm.index + bm[0].length }
                },
                raw: bm[0]
              };
            }
          }
        } catch (e) {}
      }
    }

    // 2. Block-Formeln in Live Preview (.cm-math-block, .cm-embed-block, .math-block)
    const isBlockEl = mathEl.classList.contains('math-block') ||
      mathEl.classList.contains('cm-math-block') ||
      Boolean(mathEl.closest('.cm-math-block, .math-block'));

    if (editor && docText) {
      const allFormulas = this.extractAllFormulasFromText(docText);

      if (isBlockEl) {
        const blockFormulas = allFormulas.filter(f => f.isBlock);
        if (blockFormulas.length === 1) {
          const f = blockFormulas[0];
          return {
            latex: f.latex,
            isBlock: true,
            range: {
              from: editor.offsetToPos(f.fromOffset ?? 0),
              to: editor.offsetToPos(f.toOffset ?? 0)
            },
            raw: f.raw
          };
        }

        // Mehrere Block-Formeln: Über DOM-Index der Block-Formeln ermitteln
        const viewContainer = (view as any)?.contentEl || (editor as any)?.containerEl || document.querySelector('.workspace-leaf.mod-active');
        if (viewContainer) {
          const allBlockDom = Array.from(viewContainer.querySelectorAll<HTMLElement>('.cm-math-block, .math-block'))
            .filter((el, idx, arr) => !arr.some(p => p !== el && p.contains(el)));
          const bIdx = allBlockDom.findIndex(el => el === mathEl || el.contains(mathEl) || mathEl.contains(el));
          if (bIdx >= 0 && bIdx < blockFormulas.length) {
            const f = blockFormulas[bIdx];
            return {
              latex: f.latex,
              isBlock: true,
              range: {
                from: editor.offsetToPos(f.fromOffset ?? 0),
                to: editor.offsetToPos(f.toOffset ?? 0)
              },
              raw: f.raw
            };
          }
        }
      }

      // 3. Fallback: Nächste Formel zur Koordinaten-Position
      const cmView = (editor as any).cm;
      if (cmView && typeof cmView.posAtCoords === 'function') {
        const rect = mathEl.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          const p = cmView.posAtCoords({ x: rect.left + 8, y: rect.top + 8 });
          const offset = typeof p === 'number' ? p : p?.pos;
          if (typeof offset === 'number') {
            const found = this.findFormulaAroundPos(docText, offset);
            if (found) {
              return {
                latex: found.latex,
                isBlock: found.isBlock,
                range: {
                  from: editor.offsetToPos(found.fromOffset),
                  to: editor.offsetToPos(found.toOffset)
                },
                raw: found.raw
              };
            }
          }
        }
      }
    }

    return null;
  }

  /**
   * Sucht im gesamten Dokumenttext nach der Formel an oder nahe einer Offset-Position
   */
  findFormulaAroundPos(
    docText: string,
    pos: number
  ): { latex: string; isBlock: boolean; fromOffset: number; toOffset: number; raw: string } | null {
    if (typeof pos !== 'number' || isNaN(pos)) return null;

    // 1. Display-Math $$...$$
    const blockRegex = /\$\$([\s\S]*?)\$\$/g;
    let match: RegExpExecArray | null;
    while ((match = blockRegex.exec(docText)) !== null) {
      const start = match.index;
      const end = start + match[0].length;
      if (pos >= start - 8 && pos <= end + 8) {
        return {
          latex: match[1].trim(),
          isBlock: true,
          fromOffset: start,
          toOffset: end,
          raw: match[0]
        };
      }
    }

    // 2. Inline-Math $...$
    const inlineRegex = /(?<![\$\\])\$(?!\$)([^\$\n]+?)(?<![\$\\])\$(?!\$)/g;
    while ((match = inlineRegex.exec(docText)) !== null) {
      const start = match.index;
      const end = start + match[0].length;
      if (pos >= start - 4 && pos <= end + 4) {
        return {
          latex: match[1].trim(),
          isBlock: false,
          fromOffset: start,
          toOffset: end,
          raw: match[0]
        };
      }
    }

    return null;
  }

  /**
   * Erkennt $...$ oder $$...$$ an der aktuellen Cursorposition
   */
  detectFormulaUnderCursor(
    line: string,
    ch: number
  ): { latex: string; isBlock: boolean; range: { fromCh: number; toCh: number }; raw: string } | null {
    // 1. Display-Math $$...$$
    const blockRegex = /\$\$([\s\S]*?)\$\$/g;
    let match: RegExpExecArray | null;
    while ((match = blockRegex.exec(line)) !== null) {
      const start = match.index;
      const end = start + match[0].length;
      if (ch >= start && ch <= end) {
        return {
          latex: match[1].trim(),
          isBlock: true,
          range: { fromCh: start, toCh: end },
          raw: match[0]
        };
      }
    }

    // 2. Inline-Math $...$
    const inlineRegex = /(?<![\$\\])\$(?!\$)([^\$\n]+?)(?<![\$\\])\$(?!\$)/g;
    while ((match = inlineRegex.exec(line)) !== null) {
      const start = match.index;
      const end = start + match[0].length;
      if (ch >= start && ch <= end) {
        return {
          latex: match[1].trim(),
          isBlock: false,
          range: { fromCh: start, toCh: end },
          raw: match[0]
        };
      }
    }

    return null;
  }

  /**
   * Extrahiert alle Formeln aus einem Notiztext samt Positionen
   */
  extractAllFormulasFromText(text: string): Array<ExtractedFormula> {
    const results: Array<ExtractedFormula> = [];

    // 1. Zuerst alle echten Block-Formeln finden ($$ ... $$)
    const blockRegex = /\$\$([\s\S]*?)\$\$/g;
    let bMatch: RegExpExecArray | null;
    const blockRanges: Array<{ start: number; end: number }> = [];

    while ((bMatch = blockRegex.exec(text)) !== null) {
      const raw = bMatch[0];
      const start = bMatch.index;
      const end = start + raw.length;
      blockRanges.push({ start, end });
      results.push({
        latex: bMatch[1].trim(),
        isBlock: true,
        fromOffset: start,
        toOffset: end,
        raw
      });
    }

    // 2. Dann alle echten Inline-Formeln finden ($ ... $ innerhalb einer Zeile, ohne Zeilenumbrüche!)
    const inlineRegex = /(?<![\$\\])\$(?!\$)([^\$\n]+?)(?<![\$\\])\$(?!\$)/g;
    let iMatch: RegExpExecArray | null;
    while ((iMatch = inlineRegex.exec(text)) !== null) {
      const start = iMatch.index;
      const end = start + iMatch[0].length;
      const inBlock = blockRanges.some(b => start >= b.start && end <= b.end);
      if (!inBlock) {
        results.push({
          latex: iMatch[1].trim(),
          isBlock: false,
          fromOffset: start,
          toOffset: end,
          raw: iMatch[0]
        });
      }
    }

    results.sort((a, b) => (a.fromOffset ?? 0) - (b.fromOffset ?? 0));
    return results;
  }
}

/**
 * Visuelles Formeleditor-Modal für Obsidian
 */
export class FormulaEditorModal extends Modal {
  plugin: VisualFormulaEditorPlugin;
  editor?: Editor;
  latex: string;
  isBlock: boolean;
  isInTable: boolean;
  formulaRange?: { from: { line: number; ch: number }; to: { line: number; ch: number } };
  replaceRange?: { fromCh: number; toCh: number; line?: number };
  originalLatex?: string;
  originalRaw?: string;
  activeTab: 'snippets' | 'greek' = 'snippets';

  // DOM Elemente
  previewEl: HTMLElement;
  textareaEl: HTMLTextAreaElement;
  modeDescEl: HTMLElement;
  inlineBtnEl: HTMLButtonElement;
  blockBtnEl: HTMLButtonElement;

  constructor(
    app: App,
    plugin: VisualFormulaEditorPlugin,
    editor?: Editor,
    initialLatex = '',
    initialIsBlock?: boolean,
    replaceRange?: { fromCh: number; toCh: number; line?: number },
    originalLatex?: string,
    formulaRange?: { from: { line: number; ch: number }; to: { line: number; ch: number } },
    originalRaw?: string,
    isInTable = false
  ) {
    super(app);
    this.plugin = plugin;
    this.editor = editor;

    // Filter UI-Phrasen & Begrenzer heraus
    const cleanedLatex = stripFormulaDelimiters(initialLatex);
    this.latex = cleanedLatex;
    this.isInTable = isInTable;

    // Beachte defaultMode ('block' | 'inline') aus den Plugin-Einstellungen für neue Formeln
    const defaultIsBlock = this.plugin?.settings?.defaultMode === 'block';
    const isBlockPreferred = initialIsBlock !== undefined ? initialIsBlock : defaultIsBlock;
    this.isBlock = isInTable ? false : isBlockPreferred;

    this.replaceRange = replaceRange;
    this.originalLatex = stripFormulaDelimiters(originalLatex || initialLatex);
    this.formulaRange = formulaRange;
    this.originalRaw = originalRaw;
  }

  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass('obsidian-formula-modal');

    // Header
    const header = contentEl.createDiv({ cls: 'formula-modal-header' });
    const titleContainer = header.createDiv({ cls: 'formula-modal-title' });
    titleContainer.createSpan({ cls: 'formula-sigma-badge', text: 'Σ' });
    titleContainer.createEl('h3', {
      text: this.formulaRange || this.replaceRange || this.originalLatex ? 'Edit Formula' : 'LaTeX Formula Editor'
    });

    const isEditingExisting = Boolean(this.formulaRange || this.replaceRange || this.originalLatex);

    // Subtitle
    const subtitle = contentEl.createEl('p', {
      text: isEditingExisting
        ? 'Modify and update existing formula in this cell'
        : 'Insert mathematical expressions and data-science formulas intuitively'
    });
    subtitle.style.cssText = 'font-size: 12px; color: var(--text-muted, #a1a1aa); margin: 0 0 12px 0;';

    // Quick Selection Chips (Schnellauswahl Chips)
    this.buildCatalog(contentEl);

    // LaTeX Code input field
    const editorWrapper = contentEl.createDiv({ cls: 'formula-input-wrapper' });
    const inputLabel = editorWrapper.createEl('label', { text: 'LaTeX Code:' });
    inputLabel.style.cssText = 'font-size: 11px; font-weight: 600; color: var(--text-muted, #a1a1aa); text-transform: uppercase; display: block; margin-bottom: 4px;';
    
    this.textareaEl = editorWrapper.createEl('textarea', {
      cls: 'formula-textarea',
      placeholder: 'e.g. \\mathbf{A}\\mathbf{x} = \\mathbf{b}'
    });
    this.textareaEl.setAttribute('spellcheck', 'false');
    this.textareaEl.setAttribute('autocorrect', 'off');
    this.textareaEl.setAttribute('autocapitalize', 'off');
    this.textareaEl.setAttribute('autocomplete', 'off');
    this.textareaEl.spellcheck = false;
    this.textareaEl.value = this.latex;
    this.textareaEl.rows = 3;

    this.textareaEl.oninput = () => {
      this.latex = this.textareaEl.value;
      this.updateModeFeedback();
      this.updatePreview();
    };

    // Mode choice (Radio buttons: Inline vs Block with concentric SVG)
    const modeSwitch = contentEl.createDiv({ cls: 'formula-mode-switch-row' });
    modeSwitch.style.cssText = 'display: flex; gap: 1.25rem; font-size: 13px; color: var(--text-normal, #d4d4d8); margin: 8px 0 12px 0; align-items: center; user-select: none;';

    const getRadioSvg = (checked: boolean) => `
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;display:block;">
        <circle cx="8" cy="8" r="6.75" stroke="${checked ? 'var(--interactive-accent, #a855f7)' : 'var(--background-modifier-border, #52525b)'}" stroke-width="1.5" fill="var(--background-primary, #09090b)" />
        ${checked ? '<circle cx="8" cy="8" r="3.25" fill="var(--interactive-accent, #a855f7)" />' : ''}
      </svg>
    `;

    const inlineLabel = modeSwitch.createEl('label');
    inlineLabel.style.cssText = 'display: inline-flex; align-items: center; gap: 8px; cursor: pointer;';
    const inlineIcon = inlineLabel.createSpan();
    inlineIcon.innerHTML = getRadioSvg(!this.isBlock);
    const inlineText = inlineLabel.createSpan({ text: 'Inline ($...$)' });
    inlineText.style.color = !this.isBlock ? 'var(--interactive-accent, #a855f7)' : 'var(--text-normal, #d4d4d8)';

    const blockLabel = modeSwitch.createEl('label');
    const blockIcon = blockLabel.createSpan();
    const isBlockChecked = this.isInTable ? false : this.isBlock;
    blockIcon.innerHTML = getRadioSvg(isBlockChecked);
    const blockText = blockLabel.createSpan({ text: 'Block ($$...$$)' });

    if (this.isInTable) {
      blockLabel.style.cssText = 'display: inline-flex; align-items: center; gap: 8px; cursor: not-allowed; opacity: 0.4; user-select: none;';
      blockText.style.cssText = 'color: var(--text-muted, #71717a);';
    } else {
      blockLabel.style.cssText = 'display: inline-flex; align-items: center; gap: 8px; cursor: pointer;';
      blockText.style.color = this.isBlock ? 'var(--interactive-accent, #a855f7)' : 'var(--text-normal, #d4d4d8)';
    }

    const updateRadioVisuals = () => {
      inlineIcon.innerHTML = getRadioSvg(!this.isBlock);
      inlineText.style.color = !this.isBlock ? 'var(--interactive-accent, #a855f7)' : 'var(--text-normal, #d4d4d8)';
      if (!this.isInTable) {
        blockIcon.innerHTML = getRadioSvg(this.isBlock);
        blockText.style.color = this.isBlock ? 'var(--interactive-accent, #a855f7)' : 'var(--text-normal, #d4d4d8)';
      }
    };

    inlineLabel.onclick = () => {
      this.isBlock = false;
      updateRadioVisuals();
      this.updateModeFeedback();
      this.updatePreview();
    };

    blockLabel.onclick = () => {
      if (this.isInTable) {
        return;
      }
      this.isBlock = true;
      updateRadioVisuals();
      this.updateModeFeedback();
      this.updatePreview();
    };

    this.modeDescEl = contentEl.createDiv({ cls: 'formula-mode-desc' });
    this.modeDescEl.style.cssText = 'font-size: 11px; color: var(--text-muted); margin: 2px 0 8px 0; font-family: var(--font-monospace);';
    this.updateModeFeedback();

    // Live Preview Box
    const previewWrapper = contentEl.createDiv({ cls: 'formula-preview-container' });
    const previewLabel = previewWrapper.createEl('label', { text: 'Real-time KaTeX Preview:' });
    previewLabel.style.cssText = 'font-size: 11px; font-weight: 600; color: var(--text-muted, #a1a1aa); text-transform: uppercase; display: block; margin-bottom: 4px;';
    this.previewEl = previewWrapper.createDiv({ cls: 'formula-preview-box' });

    // Footer Buttons
    const footer = contentEl.createDiv({ cls: 'formula-modal-footer' });
    footer.createSpan({
      cls: 'formula-modal-tip',
      text: 'Tip: Shortcut Mod+Shift+M opens this editor anytime in editing mode.'
    });

    const actionBtns = footer.createDiv({ cls: 'formula-modal-actions' });
    const cancelBtn = actionBtns.createEl('button', { text: 'Cancel' });
    cancelBtn.onclick = () => this.close();

    const insertBtn = actionBtns.createEl('button', {
      cls: 'mod-cta',
      text: isEditingExisting ? 'Update Formula' : 'Insert into Note'
    });
    insertBtn.style.cssText = 'background: var(--interactive-accent, #7c3aed); border-color: var(--interactive-accent-hover, #6d28d9); color: var(--text-on-accent, #ffffff); font-weight: 600;';
    insertBtn.onclick = () => this.applyToEditor();

    // Initial render & Focus
    this.updatePreview();
    setTimeout(() => {
      this.textareaEl.focus();
      this.textareaEl.select();
    }, 50);
  }

  private updateModeFeedback() {
    if (!this.modeDescEl) return;
    const clean = stripFormulaDelimiters(this.latex);
    if (this.isInTable) {
      this.modeDescEl.setText(`Saved in table as: $ ${clean || '...'} $ (Inline-Formel)`);
    } else {
      const syntax = this.isBlock ? `$$ ${clean || '...'} $$ (Block)` : `$ ${clean || '...'} $ (Inline)`;
      this.modeDescEl.setText(`Saved in note as: ${syntax}`);
    }
  }

  private updatePreview() {
    if (!this.previewEl) return;
    const trimmed = stripFormulaDelimiters(this.latex);
    if (!trimmed) {
      this.previewEl.setText('(No formula entered)');
      return;
    }

    try {
      const obs = (window as any).obsidian || require('obsidian');
      if (obs && typeof obs.renderMath === 'function') {
        const node = obs.renderMath(trimmed, this.isBlock);
        this.previewEl.empty();
        this.previewEl.appendChild(node);
        if (typeof obs.finishRenderMath === 'function') {
          obs.finishRenderMath();
        }
      } else if (typeof katex !== 'undefined') {
        this.previewEl.innerHTML = katex.renderToString(trimmed, {
          displayMode: this.isBlock,
          throwOnError: false
        });
      } else {
        this.previewEl.setText(this.isBlock ? `$$${trimmed}$$` : `$${trimmed}$`);
      }
    } catch (err) {
      this.previewEl.setText(trimmed);
    }
  }

  private insertSnippet(snippet: string) {
    const el = this.textareaEl;
    if (!el) {
      this.latex += snippet;
      this.updateModeFeedback();
      this.updatePreview();
      return;
    }

    const start = el.selectionStart || 0;
    const end = el.selectionEnd || 0;
    const prev = this.latex;
    let textToInsert = snippet;

    if (snippet === '\\text{.}' && start !== end) {
      textToInsert = `\\text{${prev.substring(start, end)}}`;
    }

    this.latex = prev.substring(0, start) + textToInsert + prev.substring(end);
    el.value = this.latex;
    this.updateModeFeedback();
    this.updatePreview();

    setTimeout(() => {
      el.focus();
      el.setSelectionRange(start + textToInsert.length, start + textToInsert.length);
    }, 10);
  }

  private buildCatalog(container: HTMLElement) {
    const catalogContainer = container.createDiv({ cls: 'formula-catalog-container' });

    // 1. Matrices & Vectors
    const matTitle = catalogContainer.createDiv({ cls: 'formula-chips-title' });
    matTitle.setText('Matrices & Vectors');
    matTitle.style.cssText = 'font-size: 11px; font-weight: 600; color: var(--text-muted, #a1a1aa); text-transform: uppercase; margin: 4px 0 6px 0;';

    const matRow = catalogContainer.createDiv({ cls: 'formula-chips-row' });
    matRow.style.cssText = 'display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px;';
    const matrixSnippets = [
      { label: '(2x2 Matrix)', code: '\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}' },
      { label: '[3x3 Matrix]', code: '\\begin{bmatrix} a_{11} & a_{12} & a_{13} \\\\ a_{21} & a_{22} & a_{23} \\\\ a_{31} & a_{32} & a_{33} \\end{bmatrix}' },
      { label: '[Column vector]', code: '\\mathbf{v} = \\begin{pmatrix} v_1 \\\\ v_2 \\\\ v_3 \\end{pmatrix}' }
    ];
    matrixSnippets.forEach(sn => {
      const chip = matRow.createEl('button', { cls: 'formula-chip', text: sn.label });
      chip.onclick = () => this.insertSnippet(sn.code);
    });

    // 2. Operators & Building Blocks
    const opTitle = catalogContainer.createDiv({ cls: 'formula-chips-title' });
    opTitle.setText('Operators & Building Blocks');
    opTitle.style.cssText = 'font-size: 11px; font-weight: 600; color: var(--text-muted, #a1a1aa); text-transform: uppercase; margin: 4px 0 6px 0;';

    const opRow = catalogContainer.createDiv({ cls: 'formula-chips-row' });
    opRow.style.cssText = 'display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px;';
    const opSnippets = [
      { label: 'Fraction (\\frac)', code: '\\frac{a}{b}' },
      { label: 'Display Fraction (\\dfrac)', code: '\\dfrac{a}{b}' },
      { label: 'Formatting \\text{.}', code: '\\text{.}' },
      { label: 'Power (x^2)', code: 'x^{2}' },
      { label: 'Subscript (x_i)', code: 'x_{i}' },
      { label: 'Square Root (\\sqrt)', code: '\\sqrt{x}' },
      { label: 'n-th Root', code: '\\sqrt[n]{x}' },
      { label: '· (\\cdot)', code: '\\cdot ' },
      { label: '±', code: '\\pm' },
      { label: '∞', code: '\\infty' },
      { label: '∇', code: '\\nabla' },
      { label: '∈', code: '\\in' },
      { label: '⊂', code: '\\subset' },
      { label: '≈', code: '\\approx' },
      { label: '≠', code: '\\neq' },
      { label: '≤', code: '\\le' },
      { label: '≥', code: '\\ge' }
    ];
    opSnippets.forEach(sn => {
      const chip = opRow.createEl('button', { cls: 'formula-chip', text: sn.label });
      chip.onclick = () => this.insertSnippet(sn.code);
    });

    // 3. Greek Symbols
    const greekTitle = catalogContainer.createDiv({ cls: 'formula-chips-title' });
    greekTitle.setText('Greek Symbols');
    greekTitle.style.cssText = 'font-size: 11px; font-weight: 600; color: var(--text-muted, #a1a1aa); text-transform: uppercase; margin: 4px 0 6px 0;';

    const greekRow = catalogContainer.createDiv({ cls: 'formula-chips-row' });
    greekRow.style.cssText = 'display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px;';
    const greekSnippets = [
      { label: 'α (alpha)', code: '\\alpha ' },
      { label: 'β (beta)', code: '\\beta ' },
      { label: 'γ (gamma)', code: '\\gamma ' },
      { label: 'δ (delta)', code: '\\delta ' },
      { label: 'ε (epsilon)', code: '\\epsilon ' },
      { label: 'θ (theta)', code: '\\theta ' },
      { label: 'λ (lambda)', code: '\\lambda ' },
      { label: 'μ (mu)', code: '\\mu ' },
      { label: 'π (pi)', code: '\\pi ' },
      { label: 'σ (sigma)', code: '\\sigma ' },
      { label: 'τ (tau)', code: '\\tau ' },
      { label: 'φ (phi)', code: '\\phi ' },
      { label: 'ψ (psi)', code: '\\psi ' },
      { label: 'ω (omega)', code: '\\omega ' },
      { label: 'Δ (Delta)', code: '\\Delta ' },
      { label: 'Θ (Theta)', code: '\\Theta ' },
      { label: 'Λ (Lambda)', code: '\\Lambda ' },
      { label: 'Σ (Sigma)', code: '\\Sigma ' },
      { label: 'Ω (Omega)', code: '\\Omega ' }
    ];
    greekSnippets.forEach(g => {
      const chip = greekRow.createEl('button', { cls: 'formula-chip', text: g.label });
      chip.onclick = () => this.insertSnippet(g.code);
    });
  }

  private applyToEditor() {
    const trimmed = stripFormulaDelimiters(this.latex);
    if (!trimmed) {
      this.close();
      return;
    }

    // Bei Block-Formel: '$$\n' + trimmed + '\n$$' (falls mehrzeilig/Block-Zeilen) oder '$$' + trimmed + '$$'
    // Wichtig: KEINE führenden oder nachfolgenden Zeilenumbrüche (\n davor/danach),
    // damit nicht nach jedem Editieren leere Zeilen darüber und darunter entstehen!
    let formatted: string;
    if (this.isBlock) {
      const hadNewlines = this.originalRaw ? this.originalRaw.includes('\n') : false;
      if (trimmed.includes('\n') || hadNewlines) {
        formatted = '$$\n' + trimmed + '\n$$';
      } else {
        formatted = '$$' + trimmed + '$$';
      }
    } else {
      formatted = '$' + trimmed + '$';
    }

    if (this.formulaRange && this.editor) {
      // 1. Replace exact document range
      this.editor.replaceRange(formatted, this.formulaRange.from, this.formulaRange.to);
      new Notice(this.isBlock ? 'Block formula ($$...$$) updated!' : 'Inline formula ($...$) updated!');
      this.close();
      return;
    }

    if (this.replaceRange && this.editor) {
      // 2. Line-based range
      const line = this.replaceRange.line !== undefined ? this.replaceRange.line : this.editor.getCursor().line;
      this.editor.replaceRange(
        formatted,
        { line, ch: this.replaceRange.fromCh },
        { line, ch: this.replaceRange.toCh }
      );
      new Notice(this.isBlock ? 'Block formula ($$...$$) updated!' : 'Inline formula ($...$) updated!');
      this.close();
      return;
    }

    if (this.editor) {
      // 3. Replace in active note
      const fullText = this.editor.getValue();
      let replaced = false;

      // When full raw string is known (including $ or $$)
      if (this.originalRaw && fullText.includes(this.originalRaw)) {
        this.editor.setValue(fullText.replace(this.originalRaw, formatted));
        replaced = true;
      } else if (this.originalLatex) {
        const origClean = stripFormulaDelimiters(this.originalLatex);
        const esc = origClean.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const flexRegex = new RegExp('(\\$\\$[\\s\\S]*?' + esc + '[\\s\\S]*?\\$\\$|\\$[\\s\\S]*?' + esc + '[\\s\\S]*?\\$)', 'm');
        if (flexRegex.test(fullText)) {
          this.editor.setValue(fullText.replace(flexRegex, formatted));
          replaced = true;
        }
      }

      if (replaced) {
        new Notice(this.isBlock ? 'Block formula ($$...$$) updated!' : 'Inline formula ($...$) updated!');
      } else {
        this.editor.replaceSelection(formatted);
        new Notice('Formula inserted into note!');
      }
    }
    this.close();
  }

  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
}

/**
 * Obsidian Settings Tab für das Plugin
 */
class FormulaEditorSettingTab extends PluginSettingTab {
  plugin: VisualFormulaEditorPlugin;

  constructor(app: App, plugin: VisualFormulaEditorPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;
    containerEl.empty();

    containerEl.createEl('h2', { text: 'Visual Math Formula Editor Settings' });

    new Setting(containerEl)
      .setName('Default Mode')
      .setDesc('Whether formulas should be inserted as block ($$...$$) or inline ($...$) by default.')
      .addDropdown(dropdown =>
        dropdown
          .addOption('block', 'Block ($$...$$)')
          .addOption('inline', 'Inline ($...$)')
          .setValue(this.plugin.settings.defaultMode)
          .onChange(async value => {
            this.plugin.settings.defaultMode = value as 'block' | 'inline';
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName('Direct click to edit')
      .setDesc('Clicking rendered formulas in editing mode directly opens the visual editor.')
      .addToggle(toggle =>
        toggle
          .setValue(this.plugin.settings.enableDirectClickEdit)
          .onChange(async value => {
            this.plugin.settings.enableDirectClickEdit = value;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName('Status bar item')
      .setDesc('Shows the "Σ Formula Editor" button in the bottom status bar.')
      .addToggle(toggle =>
        toggle
          .setValue(this.plugin.settings.enableStatusBarItem)
          .onChange(async value => {
            this.plugin.settings.enableStatusBarItem = value;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName('Show ribbon icon')
      .setDesc('Shows the Sigma icon (Σ) in the Obsidian left ribbon.')
      .addToggle(toggle =>
        toggle
          .setValue(this.plugin.settings.enableRibbonIcon)
          .onChange(async value => {
            this.plugin.settings.enableRibbonIcon = value;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName('Context menu integration')
      .setDesc('Allows right-clicking formulas or text to open the formula editor.')
      .addToggle(toggle =>
        toggle
          .setValue(this.plugin.settings.enableContextMenu)
          .onChange(async value => {
            this.plugin.settings.enableContextMenu = value;
            await this.plugin.saveSettings();
          })
      );
  }
}
